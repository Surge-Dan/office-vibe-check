App({
  onLaunch() {},
});
