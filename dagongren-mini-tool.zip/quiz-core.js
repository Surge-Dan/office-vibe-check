(function (root) {
  function validateQuestionBank(questions, types) {
    if (!Array.isArray(questions) || questions.length !== 7) throw new Error('题目数量必须为 7');
    if (!Array.isArray(types) || types.length !== 8) throw new Error('体质数量必须为 8');

    const typeIds = new Set(types.map((type) => type.id));
    if (typeIds.size !== types.length || [...typeIds].some((id) => !id)) throw new Error('体质 ID 配置无效');
    const referencedTypeIds = new Set();
    const questionIds = new Set();
    const optionIds = new Set();

    questions.forEach((question) => {
      if (!question || !question.id || questionIds.has(question.id)) throw new Error('题目 ID 配置无效');
      if (!question.title || !Array.isArray(question.options) || question.options.length !== 4) throw new Error(`题目 ${question.id} 的选项配置无效`);
      questionIds.add(question.id);
      question.options.forEach((option) => {
        if (!option.id || optionIds.has(option.id) || !option.text || !option.scores) throw new Error(`题目 ${question.id} 的选项配置无效`);
        const entries = Object.entries(option.scores);
        if (!entries.length || entries.some(([typeId, score]) => !typeIds.has(typeId) || typeof score !== 'number' || !Number.isFinite(score) || score <= 0)) throw new Error(`题目 ${question.id} 的选项配置无效`);
        entries.forEach(([typeId]) => referencedTypeIds.add(typeId));
        optionIds.add(option.id);
      });
    });

    types.forEach((type) => {
      if (!type.id || !type.code || !type.name || !type.summary || !type.quote || !type.detail || !type.color || !Array.isArray(type.tags) || type.tags.length !== 3 || !Array.isArray(type.copyVariants) || type.copyVariants.length < 5 || type.copyVariants.some((copy) => typeof copy !== 'string' || !copy.trim())) throw new Error(`体质 ${type.id || 'unknown'} 的内容配置无效`);
      if (!referencedTypeIds.has(type.id)) throw new Error(`体质 ${type.id} 没有对应选项`);
    });
    return true;
  }

  function validateProgress(index, total) {
    if (!Number.isInteger(index) || !Number.isInteger(total) || total <= 0 || index < 0 || index >= total) throw new Error('题目进度无效');
  }

  function formatProgress(index, total) {
    validateProgress(index, total);
    return `${String(index + 1).padStart(2, '0')} / ${String(total).padStart(2, '0')}`;
  }

  function formatProgressPercent(index, total) {
    validateProgress(index, total);
    return Math.round(((index + 1) / total) * 100);
  }

  function calculateResult(answers, questions, types) {
    validateQuestionBank(questions, types);
    if (!Array.isArray(answers) || answers.length !== questions.length) throw new Error('答案不完整或无效');
    const totals = Object.fromEntries(types.map((type) => [type.id, 0]));
    const tieBreak = Object.fromEntries(types.map((type) => [type.id, 0]));
    for (let index = 0; index < answers.length; index += 1) {
      const option = questions[index].options.find(({ id }) => id === answers[index]);
      if (!option) throw new Error('答案不完整或无效');
      Object.entries(option.scores).forEach(([typeId, score]) => {
        totals[typeId] += score;
        if (index === answers.length - 1) tieBreak[typeId] += score;
      });
    }
    const order = new Map(types.map((type, index) => [type.id, index]));
    const winner = types.slice().sort((a, b) => {
      const totalDiff = totals[b.id] - totals[a.id];
      if (totalDiff) return totalDiff;
      const tieDiff = tieBreak[b.id] - tieBreak[a.id];
      if (tieDiff) return tieDiff;
      return order.get(a.id) - order.get(b.id);
    })[0];
    const variantIndex = totals[winner.id] % winner.copyVariants.length;
    return { ...winner, variantIndex, quote: winner.copyVariants[variantIndex], score: totals[winner.id] };
  }

  function getResultVariant(type, variantIndex) {
    const numericIndex = Number(variantIndex);
    const safeIndex = Number.isInteger(numericIndex) && numericIndex >= 0 && numericIndex < type.copyVariants.length ? numericIndex : 0;
    return { ...type, variantIndex: safeIndex, quote: type.copyVariants[safeIndex] };
  }

  root.DagongrenMiniTool = { calculateResult, formatProgress, formatProgressPercent, getResultVariant, validateQuestionBank };
})(typeof window !== 'undefined' ? window : globalThis);
